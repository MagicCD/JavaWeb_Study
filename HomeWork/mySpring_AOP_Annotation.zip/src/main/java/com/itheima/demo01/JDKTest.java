package com.itheima.demo01;

public class JDKTest {
    public static void main(String[] args) {
        MyProxy jdkProxy = new MyProxy();
        UserDaoImpl userDao = new UserDaoImpl();
        UserDao userDao1 = (UserDao) jdkProxy.createProxy(userDao);

        userDao1.addUser();
        userDao1.deleteUser();
    }
}
