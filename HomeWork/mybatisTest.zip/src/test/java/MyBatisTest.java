import com.itheima.dao.OrdersMapper;
import com.itheima.dao.PersonMapper;
import com.itheima.dao.UsersMapper;
import com.itheima.dao.WorkerMapper;
import com.itheima.pojo.*;
import com.itheima.utils.MyBatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;


public class MyBatisTest {
    /**
     * 一对一
     */
    @Test
    public void findPersonByIdTest() {
        SqlSession session = MyBatisUtils.getSession();
        Person person = session.selectOne("com.itheima.mapper." + "PersonMapper.findPersonById", 1);

        System.out.println(person);
        session.close();
    }

    /**
     * 一对一
     */
    @Test
    public void findPersonByIdTest2() {
        SqlSession session = MyBatisUtils.getSession();
        Person person = session.selectOne("com.itheima.mapper." + "PersonMapper.findPersonById", 2);
        System.out.println(person);
        session.close();
    }

    /**
     * 一对多
     */
    @Test
    public void findOrdersTest() {
        SqlSession session = MyBatisUtils.getSession();
        Orders orders = session.selectOne("com.itheima.mapper." + "OrdersMapper.findOrdersWithPorduct", 1);
        System.out.println(orders);
        session.close();
    }

    @Test
    public void findBookByIdTest1() {
        SqlSession session = MyBatisUtils.getSession();
        Book book1 = session.selectOne("com.itheima.mapper." + "BookMapper.findBookById", 1);
        System.out.println(book1.toString());

        Book book2 = session.selectOne("com.itheima.mapper." + "BookMapper.findBookById", 1);
        System.out.println(book2.toString());
        session.close();
    }

    @Test
    public void findBookByIdTest2() {
        SqlSession session = MyBatisUtils.getSession();
        Book book1 = session.selectOne("com.itheima.mapper." + "BookMapper.findBookById", 1);
        System.out.println(book1.toString());

        Book book2 = new Book();
        book2.setId(3);
        book2.setBookName("MySQL 数据库入门");
        book2.setPrice(40.0);
        session.update("com.itheima.mapper." + "BookMapper.updateBook", book2);
        session.commit();

        Book book3 = session.selectOne("com.itheima.mapper." + "BookMapper.findBookById", 1);
        System.out.println(book1.toString());
        session.close();
    }

    @Test
    public void findBookByIdTest3() {
        SqlSession session1 = MyBatisUtils.getSession();
        SqlSession session2 = MyBatisUtils.getSession();
        Book book1 = session1.selectOne("com.itheima.mapper." + "BookMapper.findBookById", 1);
        System.out.println(book1.toString());
        session1.close();

        Book book2 = session2.selectOne("com.itheima.mapper." + "BookMapper.findBookById", 1);
        System.out.println(book2.toString());
        session2.close();
    }

    @Test
    public void findBookByIdTest4() {
        SqlSession session1 = MyBatisUtils.getSession();
        SqlSession session2 = MyBatisUtils.getSession();
        SqlSession session3 = MyBatisUtils.getSession();

        Book book1 = session1.selectOne("com.itheima.mapper." + "BookMapper.findBookById", 1);
        System.out.println(book1.toString());
        session1.close();

        Book book2 = new Book();
        book2.setId(2);
        book2.setBookName("Java Web 程序开发进阶");
        book2.setPrice(45.0);
        session2.update("com.itheima.mapper." + "BookMapper.updateBook", book2);
        session2.commit();
        session2.close();

        Book book3 = session3.selectOne("com.itheima.mapper." + "BookMapper.findBookById", 1);
        System.out.println(book3.toString());
        session3.close();
    }

    @Test
    public void findWorkerByIdTest() {
        SqlSession session = MyBatisUtils.getSession();
        WorkerMapper mapper = session.getMapper(WorkerMapper.class);
        Worker worker = mapper.selectWorker(1);
        System.out.println(worker.toString());
        session.close();
    }

    @Test
    public void insertWorkerByIdTest() {
        SqlSession session = MyBatisUtils.getSession();
        Worker worker = new Worker();
        worker.setId(4);
        worker.setName("赵六");
        worker.setAge(36);
        worker.setSex("女");
        worker.setWorker_id("1004");

        WorkerMapper mapper = session.getMapper(WorkerMapper.class);

        int result = mapper.insertWorker(worker);
        if (result > 0) {
            System.out.println("成功插入" + result + "条数据");
        } else {
            System.out.println("插入数据失败");
        }
        System.out.println(worker.toString());
        session.commit();
        session.close();
    }

    @Test
    public void updateWorkerTest() {
        SqlSession session = MyBatisUtils.getSession();
        Worker worker = new Worker();
        worker.setId(4);
        worker.setName("李华");
        worker.setAge(28);

        WorkerMapper mapper = session.getMapper(WorkerMapper.class);

        int result = mapper.updateWorker(worker);

        if (result > 0) {
            System.out.println("成功更新" + result + "条数据");
        } else {
            System.out.println("更新数据失败");
        }
        System.out.println(worker.toString());
        session.commit();
        session.close();
    }

    @Test
    public void deleteWorkerTest() {
        SqlSession session = MyBatisUtils.getSession();
        WorkerMapper mapper = session.getMapper(WorkerMapper.class);

        int result = mapper.deleteWorker(4);
        if (result > 0) {
            System.out.println("成功删除" + result + "条数据");
        } else {
            System.out.println("删除数据失败");
        }
        session.commit();
        session.close();
    }

    @Test
    public void selectWorkerByIdAndNameTest() {
        SqlSession session = MyBatisUtils.getSession();
        WorkerMapper mapper = session.getMapper(WorkerMapper.class);

        Worker worker = mapper.selectWorkerByIdAndName(3, "王五");
        System.out.println(worker.toString());
        session.close();
    }

    /**
     * 注解开发一对一查询
     */
    @Test
    public void selectPersonByIdTest() {
        SqlSession session = MyBatisUtils.getSession();
        PersonMapper mapper = session.getMapper(PersonMapper.class);

        Person person = mapper.selectPersonById(2);
        System.out.println(person.toString());
        session.close();
    }

    /**
     * 注解开发一对多查询
     */
    @Test
    public void selectUserByIdTest() {
        SqlSession session = MyBatisUtils.getSession();
        UsersMapper mapper = session.getMapper(UsersMapper.class);

        Users users = mapper.selectUserById(1);
        System.out.println(users.toString());
        session.close();
    }

    /**
     * 注解开发多对多查询
     */
    @Test
    public void selectOrdersByIdTest() {
        SqlSession session = MyBatisUtils.getSession();
        OrdersMapper mapper = session.getMapper(OrdersMapper.class);

        Orders orders = mapper.selectOrdersById(3);
        System.out.println(orders.toString());
        session.close();
    }
}
