import com.itheima.pojo.Person;
import com.itheima.utils.MyBatisUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

public class MyBatisTest {
    @Test
    public void findPersonByIdTest() {
        SqlSession session = MyBatisUtils.getSession();
        Person person = session.selectOne("com.itheima.mapper." + "PersonMapper.findPersonById", 1);

        System.out.println(person);
        session.close();
    }

    @Test
    public void findPersonByIdTest2() {
        SqlSession session = MyBatisUtils.getSession();
        Person person = session.selectOne("com.itheima.mapper." + "PersonMapper.findPersonById", 2);
        System.out.println(person);
        session.close();
    }
}
