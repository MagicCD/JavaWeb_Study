package com.itheima.demo01;

public interface UserDao {
    public void addUser();
    public void deleteUser();
}
