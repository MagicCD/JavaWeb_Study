package com.itheima.service;

public interface UserService {
    public boolean login(String name, String password);
}
